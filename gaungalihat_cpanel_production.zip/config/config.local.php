<?php
// Local Development & Testing Configuration (Git-Ignored)
return [
    'db' => [
        'host'    => getenv('DB_HOST') ?: 'localhost',
        'port'    => (int)(getenv('DB_PORT') ?: 3306),
        'name'    => getenv('DB_NAME') ?: 'womenvission_gaungali',
        'user'    => getenv('DB_USER') ?: 'womenvission_admin',
        'pass'    => getenv('DB_PASS') ?: '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'site_url' => getenv('SITE_URL') ?: 'https://gaungalihat.womenvission.in',
        'env'      => 'development',
        'debug'    => false,
    ],
    'payments' => [
        'razorpay' => [
            'enabled'    => false,
            'key_id'     => getenv('RAZORPAY_KEY_ID') ?: '',
            'key_secret' => getenv('RAZORPAY_KEY_SECRET') ?: '',
        ],
        'payu' => [
            'enabled'       => false,
            'merchant_key'  => getenv('PAYU_MERCHANT_KEY') ?: '',
            'merchant_salt' => getenv('PAYU_MERCHANT_SALT') ?: '',
            'mode'          => 'test',
        ],
        'cod' => [
            'enabled' => true,
        ],
    ],
    'google' => [
        'enabled'       => false,
        'client_id'     => getenv('GOOGLE_CLIENT_ID') ?: '',
        'client_secret' => getenv('GOOGLE_CLIENT_SECRET') ?: '',
    ],
    'security' => [
        'owner_alert_email' => 'admin@womenvission.in',
        'session_lifetime'  => 1800,
        'admin_require_2fa' => false,
    ],
];
